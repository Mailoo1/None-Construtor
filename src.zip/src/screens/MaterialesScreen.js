import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, TextInput, Modal, ScrollView, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { collection, addDoc, getDocs, deleteDoc, doc, query, where, limit } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import { colors } from '../config/theme';
import { subirImagen } from '../config/cloudinary';
import {
  guardarMaterialLocal,
  obtenerMaterialesLocal,
  eliminarMaterialLocal,
} from '../config/database';
import { logInfo } from '../utils/logger';
import { mostrarError } from '../utils/errorHandler';

const LIMITE_MATERIALES = 300;

export default function MaterialesScreen() {
  const [registros,    setRegistros]    = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [material,     setMaterial]     = useState('');
  const [cantidad,     setCantidad]     = useState('');
  const [proveedor,    setProveedor]    = useState('');
  const [recibio,      setRecibio]      = useState('');
  const [notas,        setNotas]        = useState('');
  const [loading,      setLoading]      = useState(false);
  const [sinInternet,  setSinInternet]  = useState(false);
  const [fotoEvidencia, setFotoEvidencia] = useState(null);
  const [subiendoFoto,  setSubiendoFoto] = useState(false);

  useEffect(() => { cargarRegistros(); }, []);

  const cargarRegistros = async () => {
    try {
      const uid  = auth.currentUser?.uid;
      const q    = query(collection(db, 'materiales'), where('uid', '==', uid), limit(LIMITE_MATERIALES));
      const snap = await getDocs(q);
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      data.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
      data.forEach(m => guardarMaterialLocal(m));
      setRegistros(data);
      setSinInternet(false);
    } catch (e) {
      logInfo('Sin internet, cargando materiales desde SQLite...');
      const uid   = auth.currentUser?.uid;
      const local = obtenerMaterialesLocal(uid);
      setRegistros(local.map(m => ({
        id:        m.firebase_id,
        uid:       m.uid,
        material:  m.material,
        cantidad:  m.cantidad,
        proveedor: m.proveedor,
        recibio:   m.recibio,
        notas:     m.notas,
        fechaStr:  m.fecha_str,
        horaStr:   m.hora_str,
        fecha:     m.creado_en,
      })));
      setSinInternet(true);
    }
  };

  const agregarRegistro = async () => {
    if (loading) return; // evita doble-tap / doble registro
    if (!material || !cantidad) {
      Alert.alert('Campos requeridos', 'Material y cantidad son obligatorios.');
      return;
    }
    try {
      setLoading(true);
      const uid = auth.currentUser?.uid;

      let fotoUrl = null;
      if (fotoEvidencia) {
        setSubiendoFoto(true);
        fotoUrl = await subirImagen(fotoEvidencia);
        setSubiendoFoto(false);
      }

      const ref = await addDoc(collection(db, 'materiales'), {
        uid, material, cantidad, proveedor, recibio, notas,
        fotoUrl,
        fecha:    new Date().toISOString(),
        fechaStr: new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }),
        horaStr:  new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' }),
      });
      guardarMaterialLocal({
        id: ref.id, uid, material, cantidad, proveedor, recibio, notas,
        fechaStr: new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }),
        horaStr:  new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' }),
        fecha:    new Date().toISOString(),
      });
      setMaterial(''); setCantidad(''); setProveedor('');
      setRecibio(''); setNotas(''); setFotoEvidencia(null);
      setModalVisible(false);
      cargarRegistros();
    } catch (e) { mostrarError(e, 'No se pudo guardar el material'); }
    finally { setLoading(false); setSubiendoFoto(false); }
  };

  const tomarFotoMaterial = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permiso requerido', 'Necesitamos acceso a la cámara.'); return; }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (!result.canceled) setFotoEvidencia(result.assets[0].uri);
  };

  const elegirFotoMaterial = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permiso requerido', 'Necesitamos acceso a tu galería.'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
    if (!result.canceled) setFotoEvidencia(result.assets[0].uri);
  };

  const eliminarRegistro = (id) => {
    Alert.alert('Eliminar registro', '¿Estás seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => {
        try {
          await deleteDoc(doc(db, 'materiales', id));
          eliminarMaterialLocal(id);
          cargarRegistros();
        } catch (e) {
          mostrarError(e, 'No se pudo eliminar el registro');
        }
      }},
    ]);
  };

  return (
    <View style={s.container}>
      <FlatList
        data={registros}
        keyExtractor={i => i.id}
        contentContainerStyle={{ padding: 16 }}
        ListHeaderComponent={
          <View>
            <View style={s.headerRow}>
              <Text style={s.titulo}>Materiales</Text>
              <TouchableOpacity style={s.btnAdd} onPress={() => setModalVisible(true)}>
                <Ionicons name="add" size={22} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            {sinInternet && (
              <View style={s.offlineBanner}>
                <Ionicons name="cloud-offline-outline" size={16} color={colors.warning} />
                <Text style={s.offlineText}>Sin conexión — mostrando datos locales</Text>
              </View>
            )}

            <View style={s.infoBanner}>
              <Ionicons name="information-circle-outline" size={18} color={colors.info} />
              <Text style={s.infoBannerText}>
                Registra cada vez que llegue material a la obra con fecha, hora y quién lo recibió.
              </Text>
            </View>

            <View style={s.resumen}>
              <View style={s.resumenItem}>
                <Text style={s.resumenNum}>{registros.length}</Text>
                <Text style={s.resumenLabel}>Registros</Text>
              </View>
              <View style={s.divider} />
              <View style={s.resumenItem}>
                <Text style={[s.resumenNum, { color: colors.primary }]}>
                  {new Set(registros.map(r => r.material)).size}
                </Text>
                <Text style={s.resumenLabel}>Materiales</Text>
              </View>
              <View style={s.divider} />
              <View style={s.resumenItem}>
                <Text style={[s.resumenNum, { color: colors.primary }]}>
                  {new Set(registros.map(r => r.proveedor).filter(Boolean)).size}
                </Text>
                <Text style={s.resumenLabel}>Proveedores</Text>
              </View>
            </View>

            <Text style={s.seccionLabel}>HISTORIAL DE ENTREGAS</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={s.card}>
            <View style={s.cardLeft}>
              <Ionicons name="cube-outline" size={24} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.materialNombre}>{item.material}</Text>
              <Text style={s.materialCantidad}>Cantidad: {item.cantidad}</Text>
              {item.proveedor ? (
                <View style={s.infoRow}>
                  <Ionicons name="business-outline" size={11} color={colors.textMuted} />
                  <Text style={s.infoText}>De: {item.proveedor}</Text>
                </View>
              ) : null}
              {item.recibio ? (
                <View style={s.infoRow}>
                  <Ionicons name="person-outline" size={11} color={colors.textMuted} />
                  <Text style={s.infoText}>Recibió: {item.recibio}</Text>
                </View>
              ) : null}
              {item.notas ? (
                <Text style={s.notas}>{item.notas}</Text>
              ) : null}
              {item.fotoUrl ? (
                <Image source={{ uri: item.fotoUrl }} style={s.fotoCard} resizeMode="cover" />
              ) : null}
              <View style={s.fechaRow}>
                <Ionicons name="calendar-outline" size={11} color={colors.textMuted} />
                <Text style={s.fechaText}>{item.fechaStr} · {item.horaStr}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={() => eliminarRegistro(item.id)} style={s.btnEliminar}>
              <Ionicons name="trash-outline" size={18} color={colors.danger} />
            </TouchableOpacity>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          <View style={s.vacio}>
            <Ionicons name="cube-outline" size={48} color={colors.textMuted} />
            <Text style={s.vacioText}>Sin registros de materiales</Text>
            <Text style={s.vacioSub}>Registra el primer material que llegue a la obra</Text>
          </View>
        }
      />

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <ScrollView
            style={s.modalBox}
            contentContainerStyle={{ paddingBottom: 30 }}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={s.modalHeader}>
              <Text style={s.modalTitulo}>Registrar material</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={24} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            <Text style={s.fechaAuto}>
              📅 {new Date().toLocaleDateString('es-CO', { weekday: 'long', day: '2-digit', month: 'long' })} · {new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}
            </Text>

            <Text style={s.label}>Material *</Text>
            <TextInput style={s.input} placeholder="Ej: Cemento, Arena, Varilla..."
              placeholderTextColor={colors.textMuted} value={material} onChangeText={setMaterial} />

            <Text style={s.label}>Cantidad *</Text>
            <TextInput style={s.input} placeholder="Ej: 50 bultos, 3 m³, 100 unidades"
              placeholderTextColor={colors.textMuted} value={cantidad} onChangeText={setCantidad} />

            <Text style={s.label}>Proveedor / Procedencia</Text>
            <TextInput style={s.input} placeholder="Ej: Cemex, Ferretería El Constructor"
              placeholderTextColor={colors.textMuted} value={proveedor} onChangeText={setProveedor} />

            <Text style={s.label}>Quién recibió</Text>
            <TextInput style={s.input} placeholder="Ej: Carlos Ramírez"
              placeholderTextColor={colors.textMuted} value={recibio} onChangeText={setRecibio} />

            <Text style={s.label}>Notas adicionales</Text>
            <TextInput style={[s.input, { height: 70 }]} placeholder="Observaciones, estado del material..."
              placeholderTextColor={colors.textMuted} value={notas} onChangeText={setNotas}
              multiline numberOfLines={3} />

            <Text style={s.label}>Foto del material (evidencia)</Text>
            {fotoEvidencia ? (
              <View style={{ marginBottom: 12 }}>
                <Image source={{ uri: fotoEvidencia }} style={s.fotoPreview} resizeMode="cover" />
                <TouchableOpacity onPress={() => setFotoEvidencia(null)} style={s.fotoQuitar}>
                  <Ionicons name="close-circle" size={20} color={colors.danger} />
                  <Text style={s.fotoQuitarText}>Quitar foto</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={s.fotoBtns}>
                <TouchableOpacity style={s.fotoBtn} onPress={tomarFotoMaterial}>
                  <Ionicons name="camera-outline" size={20} color={colors.primary} />
                  <Text style={s.fotoBtnText}>Cámara</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.fotoBtn} onPress={elegirFotoMaterial}>
                  <Ionicons name="image-outline" size={20} color={colors.info} />
                  <Text style={s.fotoBtnText}>Galería</Text>
                </TouchableOpacity>
              </View>
            )}

            <TouchableOpacity style={[s.btnGuardar, loading && { opacity: 0.6 }]}
              onPress={agregarRegistro} disabled={loading}>
              <Text style={s.btnGuardarText}>
                {subiendoFoto ? 'Subiendo foto...' : loading ? 'Guardando...' : 'Registrar llegada'}
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container:        { flex: 1, backgroundColor: colors.bgPrimary },
  headerRow:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  titulo:           { fontSize: 22, fontWeight: 'bold', color: colors.textPrimary },
  btnAdd:           { backgroundColor: colors.primary, width: 40, height: 40, borderRadius: 8, justifyContent: 'center', alignItems: 'center', elevation: 4 },
  offlineBanner:    { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.warning + '22', borderRadius: 8, padding: 10, marginBottom: 12, borderWidth: 1, borderColor: colors.warning + '44' },
  offlineText:      { fontSize: 12, color: colors.warning, fontWeight: '600' },
  infoBanner:       { flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: colors.info + '22', borderRadius: 8, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: colors.info + '44' },
  infoBannerText:   { flex: 1, fontSize: 12, color: colors.textSecondary, lineHeight: 18 },
  resumen:          { flexDirection: 'row', backgroundColor: colors.bgCard, borderRadius: 10, padding: 14, marginBottom: 20, borderWidth: 1, borderColor: colors.border, justifyContent: 'space-around' },
  resumenItem:      { alignItems: 'center' },
  resumenNum:       { fontSize: 20, fontWeight: 'bold', color: colors.textPrimary },
  resumenLabel:     { fontSize: 11, color: colors.textSecondary, marginTop: 2 },
  divider:          { width: 1, backgroundColor: colors.border },
  seccionLabel:     { fontSize: 11, color: colors.textMuted, letterSpacing: 1, fontWeight: '600', marginBottom: 12 },
  card:             { backgroundColor: colors.bgCard, borderRadius: 10, padding: 14, flexDirection: 'row', alignItems: 'flex-start', gap: 12, borderWidth: 1, borderColor: colors.border },
  cardLeft:         { width: 42, height: 42, borderRadius: 10, backgroundColor: colors.primary + '22', borderWidth: 1, borderColor: colors.primary + '55', justifyContent: 'center', alignItems: 'center', marginTop: 2 },
  materialNombre:   { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  materialCantidad: { fontSize: 13, color: colors.primary, fontWeight: '600', marginTop: 2 },
  infoRow:          { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  infoText:         { fontSize: 12, color: colors.textSecondary },
  notas:            { fontSize: 12, color: colors.textMuted, marginTop: 4, fontStyle: 'italic' },
  fechaRow:         { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  fechaText:        { fontSize: 11, color: colors.textMuted },
  btnEliminar:      { padding: 4 },
  vacio:            { alignItems: 'center', paddingVertical: 60, gap: 8 },
  vacioText:        { fontSize: 16, color: colors.textSecondary, fontWeight: '600' },
  vacioSub:         { fontSize: 13, color: colors.textMuted, textAlign: 'center' },
  modalOverlay:     { flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' },
  modalBox:         { backgroundColor: colors.bgCard, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderWidth: 1, borderColor: colors.border, maxHeight: '90%' },
  modalHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  modalTitulo:      { fontSize: 18, fontWeight: 'bold', color: colors.textPrimary },
  fechaAuto:        { fontSize: 12, color: colors.textSecondary, marginBottom: 16, fontStyle: 'italic' },
  label:            { fontSize: 12, color: colors.textSecondary, marginBottom: 6, letterSpacing: 0.5, textTransform: 'uppercase' },
  input:            { backgroundColor: colors.bgContainer, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 12, color: colors.textPrimary, fontSize: 14, marginBottom: 14 },
  btnGuardar:       { backgroundColor: colors.primary, borderRadius: 8, padding: 16, alignItems: 'center', marginTop: 4 },
  btnGuardarText:   { color: colors.textDark, fontWeight: 'bold', fontSize: 16 },
  fotoCard:         { width: '100%', height: 140, borderRadius: 8, marginTop: 8 },
  fotoPreview:      { width: '100%', height: 160, borderRadius: 10, marginBottom: 6 },
  fotoQuitar:       { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
  fotoQuitarText:   { fontSize: 13, color: colors.danger },
  fotoBtns:         { flexDirection: 'row', gap: 10, marginBottom: 14 },
  fotoBtn:          { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: colors.bgContainer, borderRadius: 10, paddingVertical: 12, borderWidth: 1, borderColor: colors.border },
  fotoBtnText:      { fontSize: 13, color: colors.textSecondary, fontWeight: '600' },
});